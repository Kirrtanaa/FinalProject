import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Time } from '@angular/common';
import { UserServiceService } from '../user-service.service';
export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

export class Mentor{
username:String;
password:String;
valueFrom:Time;
valueTo:Time;
mobile:String;
training:Training;
skill:Skills;
}
export class Training{
coursename:String;
percentage:Int16Array;
amountpaid:Int16Array;
amountremaining:Int16Array;
status:boolean;
}
export class Skills{
skillname:String;
}

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {
  mentorname:string;
  mentorpassword:string;
  invalidmentor: string;
  // mentorarr:String[][];
  // itr:number = -1;
  
  // auth:Authorization = new Authorization();
  private auth2:Authorization = new Authorization();
  role:Role = new Role();
  ment:Mentor=new Mentor();
  train:Training=new Training();

  // email : string;
  // password : string;

  // constructor(private mentorLogin: Router) { }

  // ngOnInit() {
  // }
  // submit() {
  //   if(this.email==null) {
  //     alert("Enter Valid Email Address");
  //   }else if(this.password==null) {
  //     alert("Enter password");
  //   }else {
  //     this.mentorLogin.navigate(['/mentor-logged']);
  //   }
  // }
  constructor(private router: Router,private service:UserServiceService) { }

  ngOnInit() {
  }
store(user){
  this.service.getloginmentor(user).subscribe(value=>this.auth2=value);
}
  mentorlogin(){
    if((this.mentorname != null)&&(this.mentorpassword != null)){
      
      console.log(this.auth2.password);
      console.log(this.auth2.roleid.roleid);
      if((this.mentorpassword == this.auth2.password)&&(this.auth2.roleid.roleid == 1)){
        this.invalidmentor =  "";
        this.router.navigate(['/admin-logged',this.mentorname]);
      }
      else  if((this.mentorpassword == this.auth2.password)&&(this.auth2.roleid.roleid == 2)){
        this.invalidmentor =  "";
        this.router.navigate(['/mentor-logged',this.mentorname]);
      } else  if((this.mentorpassword == this.auth2.password)&&(this.auth2.roleid.roleid == 3)){
        this.invalidmentor =  "";
        this.router.navigate(['/user-logged',this.mentorname]);
      }
      else{
        this.invalidmentor = "Not a registered mentor!!!";
      }
    }
    else{
      this.invalidmentor = "Enter valid details!!!";
    }
  }


}
