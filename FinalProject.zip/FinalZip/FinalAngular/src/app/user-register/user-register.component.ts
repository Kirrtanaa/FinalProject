import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

export class User{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}
export class Userprofile{
  username:string;
  password:string;
  role:Role;
}

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {
  username:string;
  mail:string;
  password:string;
  val:string;

  invaliduser:string;
  openform:boolean = false;

  user:User=new User();
  profile:Userprofile=new Userprofile();
  role:Role=new Role();
  constructor(private router: Router,private service:UserServiceService) {

   }



  // name : string;
  // email : string;
  // password : string;
  // repassword : string;

  ngOnInit() {
  }
  // submit() {
  //   if(this.name==null) {
  //     alert("Enter Name");
  //   }else if(this.email==null) {
  //     alert("Enter Valid Email Address");
  //   }else if(this.password==null) {
  //     alert("Enter password");
  //   }else if(this.repassword==null) {
  //     alert("Re-enter password");
  //   }else if(this.password!=this.repassword) {
  //     alert("Passwords doesn't match");
  //   }else {
  //     this.userRegister.navigate(['/user']);
  //   }
  // }

  closeform(){
    this.openform = false;
  }

  usersign(){
    if(this.username!=null && this.mail!=null && this.password!=null){
      this.user.username=this.username;
      this.user.mail=this.mail;
      this.user.password=this.password;
      this.role.roleid=3;
      this.role.rolename="user";
      this.user.roleid=this.role;
      this.service.savesignup(this.user).subscribe();
  
      this.profile.username=this.username;
      this.profile.password=this.password;
      this.profile.role=this.role;
      this.service.saveuser(this.profile).subscribe();
  
      // this.service.abc(this.val).subscribe(value=>);
  
      this.username=null;
      this.mail=null;
      this.password=null;
      this.val="";
      this.router.navigate(['/mentor']);
      this.closeform();
      }
      else{
        this.val = "Enter valid details";
      }
    
  }



  // checkuser(){
  //   if((this.fname==null)||(this.lname==null)||(this.mail==null)||(this.passw==null)){
  //     this.invaliduser = "Enter valid details!!!";
  //   }
  //   else {
  //     this.invaliduser = "";
  //     this.router.navigate(['/usermainpage']);
  // }
  // }

}
