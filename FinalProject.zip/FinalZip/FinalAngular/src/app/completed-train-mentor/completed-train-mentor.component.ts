import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { UserServiceService } from '../user-service.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-completed-train-mentor',
  templateUrl: './completed-train-mentor.component.html',
  styleUrls: ['./completed-train-mentor.component.css']
})
export class CompletedTrainMentorComponent implements OnInit {

  // constructor(private httpservice : HttpClient) { }

  // course : string[];

  // ngOnInit() {
  //   this.httpservice.get('../../assets/mentorCompleted.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )
  // }


  dummy:string;

  private completed : string [];
  private mname:string;

  constructor(private httpservice : HttpClient,private router: Router,private service: UserServiceService,private route: ActivatedRoute) { }

  ngOnInit(){
    this.reloaddata();
    this.dummy = this.route.snapshot.paramMap.get('mname');
  }

  reloaddata(){
    this.service.getmentorcompleted().subscribe(value=>this.completed=value as string[]);
  }
}