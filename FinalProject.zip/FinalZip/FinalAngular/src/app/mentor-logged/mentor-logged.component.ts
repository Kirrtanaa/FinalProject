import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-logged',
  templateUrl: './mentor-logged.component.html',
  styleUrls: ['./mentor-logged.component.css']
})
export class MentorLoggedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
