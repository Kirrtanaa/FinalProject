import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

export class Mentor{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}
@Component({
  selector: 'app-mentor-register',
  templateUrl: './mentor-register.component.html',
  styleUrls: ['./mentor-register.component.css']
})
export class MentorRegisterComponent implements OnInit {

  // name : string;
  // email : string;
  // password : string;
  // repassword : string;

  // constructor(private mentorRegister: Router) { }

  // ngOnInit() {
  // }
  // submit() {
  //   if(this.name==null) {
  //     alert("Enter Name");
  //   }else if(this.email==null) {
  //     alert("Enter Valid Email Address");
  //   }else if(this.password==null) {
  //     alert("Enter password");
  //   }else if(this.repassword==null) {
  //     alert("Re-enter password");
  //   }else if(this.password!=this.repassword) {
  //     alert("Passwords doesn't match");
  //   }else {
  //     this.mentorRegister.navigate(['/mentor']);
  //   }
  // }

  mname:string;
  mpass:string;
  val:string;
  
  mentorname:string;
  mail:string;
  password:string;
  
  invalidmentor:string;
  openform:boolean = false;

  mentor:Mentor=new Mentor();
  role:Role=new Role();
  constructor(private router: Router,private service:UserServiceService) {

   }
   ngOnInit() {
  }
  closeform(){
    this.openform = false;
  }


  mentorsign(){
    if(this.mentorname!=null && this.mail!=null && this.password!=null){
    this.mentor.username=this.mentorname;
    this.mentor.mail=this.mail;
    this.mentor.password=this.password;
    this.role.roleid=2;
    this.role.rolename="mentor";
    this.mentor.roleid=this.role;
    this.service.savementor(this.mentor).subscribe();

    this.mentorname=null;
    this.mail=null;
    this.password=null;
    this.val="";
    this.router.navigate(['/mentor']);
    this.closeform();
    }
    else{
      this.val = "Enter valid details";
    }
    
  }



}
