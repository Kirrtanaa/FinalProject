import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { Router } from '@angular/router';
import {UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-mentor-details',
  templateUrl: './mentor-details.component.html',
  styleUrls: ['./mentor-details.component.css']
})
export class MentorDetailsComponent implements OnInit {

  // constructor(private httpservice : HttpClient) { }

  // course : string[];

  // ngOnInit() {
  //   this.httpservice.get('../../assets/mentorDetails.json').subscribe(

  //     data=>{
  //       this.course = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )

  
  adminmainprint:number = 0;
  adder:string;
  minus:string;
  
  discount:  number = 0;
  addprice: number = 0;
  
  private technologies: string[];
  private users: string[];
  private mentor: string[];
  
  constructor(private httpservice : UserServiceService,private router: Router) {
   }

   ngOnInit() {
    // this.showtech();
    this.reloadData();
  }
    // this.httpservice.get('../../assets/mentordetails.json').subscribe(

    //   data=>{
    //     this.mentor = data as string[];
    //   },
    //   (err : HttpErrorResponse) => {
    //     console.log(err.message);
    //   }
    

   
  //   this.httpservice.get('../../assets/userdetails.json').subscribe(

  //     data=>{
  //       this.users = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   )

  // }


  

   onSubmitt()
  {
    if(this.adder!=""){
    this.httpservice.savetechnology(this.adder).subscribe(data=>console.log(data),error=>console.log(error));
    this.adder = "";
    } 
    if(this.minus!=""){
    this.httpservice.removetechnology(this.minus).subscribe(data=>console.log(data),error=>console.log(error));
    this.minus = "";
    }
  }

  showtech(){
    this.httpservice.displaytechnology().subscribe(value=>this.technologies=value as string[]);
  }

  reloadData() {
    this.httpservice.getblockmentors().subscribe(value=>this.mentor=value as string[]);
  }

  // adddelete(){
  //   if(this.adder!=null) this.technologies.push(this.adder);
  //   if(this.minus!=null) {
  //     for(let find=0;find<this.technologies.length;find++){
  //       if(this.technologies[find]==this.minus) {
  //         this.technologies.splice(find,1);
  //         break;
  //       }
  //     }
  //   }
  //   this.adder = null;
  //   this.minus = null;
  // }

 
}
