export class CompletedTrainMentor {
    trainername: string;
    course: string;
    completion: Int16Array;
}