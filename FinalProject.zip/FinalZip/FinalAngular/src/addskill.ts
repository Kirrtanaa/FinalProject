export class EditTechnology{
    skillid:Int16Array;
    skillname:string;
}