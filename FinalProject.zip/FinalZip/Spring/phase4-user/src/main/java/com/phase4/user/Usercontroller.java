package com.phase4.user;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


@CrossOrigin(value="http://localhost:4200")
@Controller    
@RequestMapping(value= {"/user"}) 
public class Usercontroller {

	@Autowired 
	private Userprofilerepository uprep;
	
	@Autowired 
	private Usertrainingrepository utrep;
	
	@PostMapping(value= {"/addentry"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String adduser (@Valid @RequestBody Userprofile profile) {
		
		uprep.save(profile);
		return "User Saved";
	}
	
	@GetMapping(value= {"/profile"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody List<Userprofile> profile () {
		return (List<Userprofile>) uprep.findAll();
		
	}
	
	
	/*****************************************************************************/
	
	
	@RequestMapping(value= {"/"}) 
	public @ResponseBody String usertraining () {
		
		utrep.save(new Usertraining(1,1, "Aron", "C",75 , false));
		utrep.save(new Usertraining(2,2, "Bravio", "C#",55 , false));
		utrep.save(new Usertraining(3,3, "Roger", "C++",100 , true));
		utrep.save(new Usertraining(4,4, "Derth", "C",80 , false));
		return "User Training Saved";
	}
	
	@PostMapping(value= {"/addtraining"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addtraining (@Valid @RequestBody Usertraining profile) {
		utrep.save(profile);
		return "Training Saved";
	}
	
	@GetMapping(value= {"/training"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody List<Usertraining> training() {
		return (List<Usertraining>) utrep.findAll();
	}
	
	@GetMapping(value= {"/completed"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Usertraining> completed () {
		
		List<Usertraining> all = (List<Usertraining>)utrep.findAll();
		List<Usertraining> comp = new ArrayList<Usertraining>();
		
		for(Usertraining check:all) if(check.getStatus()) comp.add(check);
			
		return comp;
	}
	
	@GetMapping(value= {"/current"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Usertraining> current() {
		
		List<Usertraining> all = (List<Usertraining>)utrep.findAll();
		List<Usertraining> current = new ArrayList<Usertraining>();
		
		for(Usertraining check:all) if(!check.getStatus()) current.add(check);
			
		return current;
	}
	
	/*******************************************************************************/
	
}
