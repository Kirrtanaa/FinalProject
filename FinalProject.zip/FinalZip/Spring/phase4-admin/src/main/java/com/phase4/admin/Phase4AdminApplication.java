package com.phase4.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class Phase4AdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase4AdminApplication.class, args);
	}

}
