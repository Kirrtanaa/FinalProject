package com.phase4.admin;

import org.springframework.data.repository.CrudRepository;
import com.phase4.admin.Skill;

public interface Skillsrepository extends CrudRepository<Skill,Integer> {

}
