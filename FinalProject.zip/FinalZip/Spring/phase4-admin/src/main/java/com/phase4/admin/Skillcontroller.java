package com.phase4.admin;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@CrossOrigin(value="http://localhost:4200")
@Controller    
@RequestMapping(value= {"/admin"})
public class Skillcontroller {
	
	@Autowired 
	private Skillsrepository Srep;
	
	@GetMapping(value= {"/addskill/{adder}"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String add (@Valid @PathVariable String adder) {
		Skill s = new Skill();
		s.setSkillname(adder);
		Srep.save(s);
		return "Skill Saved";
	}
	
	@GetMapping(value= "/remove/{minus}",produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String delete (@Valid @PathVariable String minus) {
		Iterable<Skill> all = Srep.findAll();
		for(Skill skill:all) {
			if(skill.getSkillname().equals(minus)) {
				Srep.deleteById(skill.getSkillid());
			}
		}
		return "Skill Removed";
	}
	
	@GetMapping(value= "/allskills",produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Skill> skills () {
		return Srep.findAll();
	}


//	@RequestMapping(value= {"/"}) 
//	public @ResponseBody String addNewUser () {
////		Map<Integer,String> person = new HashMap<Integer,String>();
//		
//		Rrep.save(new Role(1,"Admin"));
//		Rrep.save(new Role(2,"Mentor"));
//		Rrep.save(new Role(3,"User"));
//
//		return "Saved";
//	}
	
//	@GetMapping(value= {"/all"})
//	public @ResponseBody Iterable<Authorization> getAllUsers() {
//		return Arep.findAll();
//	}
}
