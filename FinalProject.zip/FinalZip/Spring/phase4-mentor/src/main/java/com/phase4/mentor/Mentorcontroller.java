package com.phase4.mentor;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@CrossOrigin(value="http://localhost:4200")
@Controller    
@RequestMapping(value= {"/mentor"}) 
public class Mentorcontroller {

	@Autowired 
	private Mentorprofilerep mentor;
	
	@Autowired 
	private Trainingrep tr;
	
	@Autowired 
	private Skillsrep sr;
	
	@Autowired
	private Rolerepository rr;
	
	@PostMapping(value= {"/addentry"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addNew (@Valid @RequestBody Mentorprofile val) {
		
		mentor.save(val);
		return "ADDED";
	}
	
	@GetMapping(value= {"/profile"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Mentorprofile> profile () {
		return mentor.findAll();
	}
	
	@GetMapping(value= {"/id"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Optional<Mentorprofile> profileid (@RequestBody Integer ids) {
		return mentor.findById(ids);
	}
	
	@GetMapping(value= {"/completed"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Training> completed () {
		
		List<Training> all = (List<Training>)tr.findAll();
		List<Training> comp = new ArrayList<Training>();
		
		for(Training check:all) if(check.getStatus()) comp.add(check);
			
		return comp;
	}
	
	@GetMapping(value= {"/current"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Iterable<Training> current() {
		
		List<Training> all = (List<Training>)tr.findAll();
		List<Training> current = new ArrayList<Training>();
		
		for(Training check:all) if(!check.getStatus()) current.add(check);
			
		return current;
	}
	/*************************************************************************************/
	
//	@Autowired 
//	private Skillsrep skill;
//	
//	@PostMapping(value= {"/addskills"},produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody String addskill (@Valid @RequestBody Skills profile) {
//		
//		skill.save(profile);
//		return "Mentor Saved";
//	}
//	
//	@GetMapping(value= {"/skill"},produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody Iterable<Skills> display () {
//		return skill.findAll();
//	}
	
}
