package com.phase4.mentor;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface Trainingrep extends CrudRepository<Training, Integer>{

	
}
