package com.phase4.security;

import java.util.*;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@CrossOrigin(value="http://localhost:4200")
@Controller    
@RequestMapping(value= {"/main"}) // This means URL's start with /demo (after Application path)
public class Securitycontroller {
	
	boolean once = true;
	
	@Autowired 
	private Authorizationrepository Authrep;
	
	@Autowired 
	private Rolerepository Rolerep;
	
	@PostMapping(value= {"/addentry"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addNew (@Valid @RequestBody Authorization authority) {
		
		Authrep.save(authority);
		return "ADDED";
	}
	
	@GetMapping(value= {"/{username}"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody Authorization login (@Valid @PathVariable String username) {
		Authorization a = Authrep.findByUsername(username);
//		Iterable<Authorization> a = Authrep.findAll();
//		for(Authorization aa: a) {
//			if(aa.getUsername().equals(tech)) {
//				return aa;
//			}
//		}
		return a;
	}
	
//	@GetMapping(value= "/delete/{id}",produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody String delete (@Valid @PathVariable int id) {
//		try {
//			if(id!=1) {
//				Authrep.deleteById(id);
//				return "DELETED";
//			}
//			else return "UNABLE TO DELETE ADMIN";
//		}catch(Exception e) {
//			return "NO SUCH ID FOUND TO DELETE";
//		}
//	}
	
	
//	@GetMapping(value= "/block/{id}",produces = MediaType.APPLICATION_JSON_VALUE) 
//	public @ResponseBody String block (@Valid @PathVariable int id) {
//		try {
//			if(id!=0) {
//				Iterable<Authorization> a = Authrep.findAll();
//				for(Authorization aa:a) {
//					if(aa.getId()==id) {
//						if(aa.getBlock()) {
//							aa.setBlock(false);
//							return "BLOCKED";
//						}
//						else {
//							aa.setBlock(true);
//							return "UNBLOCKED";
//						}
//					}
//				}
//			}
//			else return "UNABLE TO BLOCK ADMIN";
//		}catch(Exception e) {
//			return "NO SUCH ID FOUND TO BLOCK";
//		}
//		return null;
//	}

	@RequestMapping(value= {"/"}) 
	public @ResponseBody String addNewUser () {
		
//		if(once) {
		
		Rolerep.save(new Role(1,"Admin"));
		Rolerep.save(new Role(2,"Mentor"));
		Rolerep.save(new Role(3,"User"));
		Authrep.save(new Authorization("Admin","Admin","itz@gmail",new Role(1,"Admin")));
return "Saved";
//		once = false;
//		
//		return "Roles and Admin Saved";
//		} else return "Roles and Admin already saved!!!";
	}
	
	@GetMapping(value= {"/all"})
	public @ResponseBody Iterable<Authorization> getAllUsers() {
		return Authrep.findAll();
	}
}