package com.phase4.security;

import org.springframework.data.repository.CrudRepository;

public interface Rolerepository extends CrudRepository<Role, Integer> {

}
